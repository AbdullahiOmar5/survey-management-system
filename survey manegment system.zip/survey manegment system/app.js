const express = require('express');
const connectDB = require('./config/db');
const userRoutes = require('./Routes/userRoutes');
const surveyRoutes = require('./Routes/SurveyRoutes'); // Make sure this is correctly referenced
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const path = require('path');
const User = require('./models/User');
const Survey = require('./models/Survey'); // Ensure the Survey model is imported

const app = express();

// Database connection
connectDB();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// View engine setup
app.set('view engine', 'ejs');           // Set view engine to EJS
app.set('views', path.join(__dirname, 'views')); // Set views folder

// Route for dashboard
app.get('/dashboard', async (req, res) => {
    try {
        const surveys = await Survey.find(); // Fetch all surveys from the database
        res.render('dashboard', { surveys }); // Pass surveys to the dashboard view
    } catch (error) {
        console.error("Error fetching surveys:", error);
        res.status(500).send("Error fetching surveys");
    }
});

// Route for user page
app.get('/user', (req, res) => {
  res.render('user');
});

// Route for survey management
app.get('/survey_management', (req, res) => {
  res.render('survey_management');
});

// Route for response analysis
app.get('/response_analysis', (req, res) => {
  res.render('response_analysis');
});

// Route for forget password
app.get('/forgetpassword', (req, res) => {
  res.render('forgetpassword');
});

// User routes
app.use('/', userRoutes);

// Survey Routes
app.use('/api', surveyRoutes); // Use surveyRoutes to handle API routes

// Password reset route
app.post('/reset-password', async (req, res) => {
  try {
    const { username, newPassword } = req.body;

    // Find user by username
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Hash the new password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(newPassword, salt);

    // Update the user's password in the database
    user.password = hashedPassword;
    await user.save();

    res.json({ message: 'Password updated successfully' });
  } catch (error) {
    console.error('Error updating password:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Server listen
const PORT = process.env.PORT || 3008;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
