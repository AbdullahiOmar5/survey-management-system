const express = require('express');
const router = express.Router();
const Survey = require('../models/Survey');
const SurveyController = require('../controllers/SurveyController');

// Delete Survey Route
router.delete('/survey/:id', async (req, res) => {
    try {
        const surveyId = req.params.id;
        console.log(`Request to delete survey with ID: ${surveyId}`); // Log codsiga delete
        await Survey.findByIdAndDelete(surveyId);
        res.status(200).json({ message: 'Survey deleted successfully' });
    } catch (error) {
        console.error("Error deleting survey:", error);
        res.status(500).json({ message: 'Error deleting survey' });
    }
});

// Edit Survey Route
router.put('/survey/:id', async (req, res) => {
    try {
        const surveyId = req.params.id;
        const updatedData = req.body;
        console.log(`Request to update survey with ID: ${surveyId}`, updatedData); // Log codsiga update
        const updatedSurvey = await Survey.findByIdAndUpdate(surveyId, updatedData, { new: true });
        res.status(200).json(updatedSurvey);
    } catch (error) {
        console.error("Error updating survey:", error);
        res.status(500).json({ message: 'Error updating survey' });
    }
});

// API to get survey stats
router.get('/survey-stats', async (req, res) => {
    try {
        console.log("Request to fetch survey stats"); // Log codsiga stats
        const totalSurveys = await Survey.countDocuments();
        const totalResponses = await Survey.aggregate([
            { $group: { _id: null, total: { $sum: "$responses" } } }
        ]);
        const completionRate = totalSurveys > 0 ? (totalResponses[0].total / totalSurveys) * 100 : 0;

        res.json({
            totalSurveys,
            totalResponses: totalResponses[0] ? totalResponses[0].total : 0,
            completionRate: completionRate.toFixed(2)
        });
    } catch (error) {
        console.error("Error fetching survey stats:", error);
        res.status(500).json({ message: "Error fetching survey stats." });
    }
});

// Create a new survey
router.post('/survey/newsurvey', (req, res, next) => {
    console.log("Request to create a new survey", req.body); // Log codsiga new survey
    SurveyController.createSurvey(req, res, next);
});

// Add question to survey
router.post('/survey/addsurveyques', (req, res, next) => {
    console.log("Request to add question to survey", req.body); // Log codsiga add question
    SurveyController.addQuestoSurvey(req, res, next);
});

// Get all surveys with sorting and search functionality
router.get('/surveys', async (req, res) => {
    try {
        const sortBy = req.query.sort === 'created-date' ? { created_at: -1 } : { title: 1 };
        const searchTerm = req.query.search || "";
        console.log(`Request to fetch surveys with sort: ${sortBy}, search: ${searchTerm}`); // Log codsiga fetch surveys
        const surveys = await Survey.find({
            title: { $regex: searchTerm, $options: "i" }
        }).sort(sortBy);
        res.json(surveys);
    } catch (error) {
        console.error("Error fetching surveys:", error);
        res.status(500).json({ message: 'Error fetching surveys' });
    }
});

// Get all surveys using SurveyController
router.get('/survey', (req, res, next) => {
    console.log("Request to get all surveys"); // Log codsiga get all surveys
    SurveyController.getSurveys(req, res, next);
});

// Get a survey by ID
router.get('/survey/:id', (req, res, next) => {
    console.log(`Request to get survey with ID: ${req.params.id}`); // Log codsiga get survey by ID
    SurveyController.getSurveyById(req, res, next);
});

// Update a survey using SurveyController
router.put('/survey/:id', (req, res, next) => {
    console.log(`Request to update survey with ID: ${req.params.id}`, req.body); // Log codsiga update survey
    SurveyController.updateSurvey(req, res, next);
});

// Delete a survey using SurveyController
router.delete('/survey/:id', (req, res, next) => {
    console.log(`Request to delete survey with ID: ${req.params.id}`); // Log codsiga delete survey
    SurveyController.deleteSurvey(req, res, next);
});

module.exports = router;
