const Survey = require('../models/Survey');
const Question = require('../models/Question');

// Create a new survey
exports.createSurvey = async (req, res) => {
    try {
        const survey = new Survey(req.body);
        survey.status = false;
        const savedSurvey = await survey.save();
        res.status(201).json(savedSurvey);
    } catch (error) {
        console.error("Error creating survey:", error);
        res.status(400).json({ message: error.message });
    }
};

// Add questions to a survey
exports.addQuestoSurvey = async (req, res) => {
    try {
        const questions = req.body.questions;

        if (!Array.isArray(questions)) {
            return res.status(400).json({ message: "Questions must be an array" });
        }

        const savedQuestions = [];
        for (const element of questions) {
            const questionData = {
                survey_id: req.body.surveyId,
                type: element.response_type,
                question_text: element.text,
                options: element.option || [] // Make sure options is an array
            };
            const question = new Question(questionData);
            const savedQuestion = await question.save();
            savedQuestions.push(savedQuestion);
        }

        res.status(201).json({ message: 'Questions added successfully', questions: savedQuestions });
    } catch (error) {
        console.error("Error adding questions:", error);
        res.status(400).json({ message: error.message });
    }
};

// Get all surveys
exports.getSurveys = async (req, res) => {
    try {
        const surveys = await Survey.find();
        res.status(200).json(surveys);
    } catch (error) {
        console.error("Error fetching surveys:", error);
        res.status(500).json({ message: error.message });
    }
};

// Get a survey by ID
exports.getSurveyById = async (req, res) => {
    try {
        const survey = await Survey.findById(req.params.id);
        if (!survey) return res.status(404).json({ message: "Survey not found" });
        res.status(200).json(survey);
    } catch (error) {
        console.error("Error fetching survey by ID:", error);
        res.status(500).json({ message: error.message });
    }
};

// Update a survey
exports.updateSurvey = async (req, res) => {
    try {
        const updatedSurvey = await Survey.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updatedSurvey) return res.status(404).json({ message: "Survey not found" });
        res.status(200).json(updatedSurvey);
    } catch (error) {
        console.error("Error updating survey:", error);
        res.status(400).json({ message: error.message });
    }
};

// Delete a survey
exports.deleteSurvey = async (req, res) => {
    try {
        const deletedSurvey = await Survey.findByIdAndDelete(req.params.id);
        if (!deletedSurvey) return res.status(404).json({ message: "Survey not found" });
        res.status(200).json({ message: "Survey deleted successfully" });
    } catch (error) {
        console.error("Error deleting survey:", error);
        res.status(500).json({ message: error.message });
    }
};
